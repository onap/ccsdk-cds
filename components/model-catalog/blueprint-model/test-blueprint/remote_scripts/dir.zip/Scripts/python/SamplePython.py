#!/usr/bin/python

import sys

print(sys.argv[1])