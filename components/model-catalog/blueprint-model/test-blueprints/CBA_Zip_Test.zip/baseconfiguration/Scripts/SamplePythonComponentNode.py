from com.brvith.orchestrator.core.interfaces import ComponentNode

class SamplePythonComponentNode(ComponentNode):
    def prepare(self, context, componentContext):
        return None

    def prepare(self, context, componentContext):
        return None